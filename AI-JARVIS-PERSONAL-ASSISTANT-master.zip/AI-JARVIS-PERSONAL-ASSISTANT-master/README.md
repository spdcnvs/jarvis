# AI-JARVIS-PERSONAL-ASSISTANT
In this project i will be sharing you my latest Ai project,Automated Ironman helmet with Ai jarvis as personal assistant  using Raspberry pi 4b Softwares or coding part An ai chatbot is trained for particular intents to intitate and interact good and human friendly converstions,it will do home automations(switch on and off light and fan), search wikipedia ,play songs from youtube,can get the time,can set reminders
i will be communicating with jarvis through the earphone connected to my PC .if you have usb soundcard with mic, u can directly 
connect it to the raspberry pi no NEED OF LAPTOP.my laptop will communicating to jarvis through SSH protocol .
From my laptop the speech will be converted to text and it will written inside  a particular file of raspberry pi each each time it recieves the voice.the raspberry pi checks the text file contains any data and give it to the ai trained model for classification
likewise it will give user friendly converstaions and chats
The raspi is connected to relays based on the decisions of the chatbot the light or the fan gets on or off and similarly the helmet
MY PROJECT VIDEO LINK 
THE AUTOMATED IRON MAN HELMET AND AI JARVIS 
LINK-https://youtu.be/MlT1fxBZIAY


Guys this project is result of 3.5 months hardwork on coding part and making up hardware took only 4-5days
IF YOU HAVE ANY QUERIES OR DOUBTS COMMENT BELOW MY VIDEO


EXECUTION
DOWNLOAD ALL THE files here
on your pc windows or linux or mac execute the file -jarvis_client_pc_side.py you need only this file on your pc
put your raspi ip address ,login name ,password in the file

and all other files should be copied to this location of raspberry pi - home/pi/

hope you have installed the required libraries like pandas ,nltk,tensorflow etc
