# Jessica-A-JARVIS-like-Assistant
This project name is Jessica made in python language and you can use it for increasing your work productivity especially for coders who search lot while coding and for students too.


The main feature or the shinning point about this Assistant is by speaking "Create Content" command you can ask her to create content, it scrapes the top results from google and create a summarized and meaningful content by using NLP Algorithm.

Other features:

# Sending emails
speak "Send email" for sending emails
# Opening softwares and youtube or google
"Open /software or program name/" for opening
# Wikisearch 
"/topic name/ wikipedia" for wikipeda search

and other commands.

I improvised this idea by adding content creation feature, by your help and forks it will do many others things , hope you'll like it and enhance it.
Thanks

warning: please change the directories according to your system.
